//
//  Configs.swift
//  PawPal
//
//  Created by Yitian Guo on 11/20/23.
//

import Foundation
class Configs{
    static let tableViewMomentsID = "tableViewMomentsID"
    static let tableViewChatsID = "tableViewChatsID"
    static let tableViewMessageID = "tableViewMessageID"
    static let tableViewContactsID = "tableViewContactsID"
    static let tableViewNewFriendsID = "tableViewNewFriendsID"
    static let tableViewOptionsID = "tableViewOptionsID"
}
