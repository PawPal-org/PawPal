//
//  Configs.swift
//  PawPal
//
//  Created by Schromeo on 11/20/23.
//

import Foundation

class MapConfigs{
    static let placeIdentifier = "placeIdentifier"
    static let searchTableViewID = "searchTableViewID"
}
